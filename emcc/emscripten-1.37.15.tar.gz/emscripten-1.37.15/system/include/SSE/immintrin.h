#ifndef __emscripten_immintrin_h__
#define __emscripten_immintrin_h__

// Include all the *mmintrin.h headers that Emscripten has.
#include <xmmintrin.h>
#include <emmintrin.h>

#endif
