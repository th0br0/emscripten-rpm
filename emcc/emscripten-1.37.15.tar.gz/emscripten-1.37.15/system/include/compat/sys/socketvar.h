#ifndef _COMPAT_SOCKETVAR_H
#define _COMPAT_SOCKETVAR_H

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/socket.h>

#ifdef __cplusplus
}
#endif

#endif
